/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xil_cache.h"
#include "xcde_emc_bench.h"
#include "xtime_l.h"
#include "math.h"
#include "xdebug.h"

int main()
{
	XTime tEnd, tCur,tCurrand;
		float A[50],B[50];
		float tUsed,tallused=0;


	    init_platform();
	    XTime_GetTime(&tCurrand);		//��ȡ��ʼʱ��
		srand((unsigned)tCurrand );
		 print("\nAAAAAAAA\n\r");
		 for(int k=0;k<51;k++){
			for(int i=0;i<50;i++){
				A[i]=0;
			}
		//		A[i]=i+0.233;
			A[3] = (int)(1+rand()%(10000))+100;;
			A[4] = 100;
			A[5] = 2;
			A[6] = -5.12;
			A[7] = 5.12;
	//		for(int i=0;i<10;i++){
	//			printf("%f ",A[i]);
	//		}
	//		 print("\n\r");
			XCde_emc_bench hlsconv;
			XCde_emc_bench_Config *ExamplePtr;


	//		printf("Look up the device configuration.\n");
			ExamplePtr=XCde_emc_bench_LookupConfig(XPAR_CDE_EMC_BENCH_0_DEVICE_ID);
			if(!ExamplePtr){
				printf("Error, lookup failed!");
				return XST_FAILURE;
			}

	//		printf("Initialize the Device\n");
			int status=XCde_emc_bench_CfgInitialize(&hlsconv,ExamplePtr);
			if(status!=XST_SUCCESS)
			{
				printf("Error, can't initialize accelerator.\n");
				return XST_FAILURE;
			}
			/*
			int status=XTest_Initialize(&hlsconv, XPAR_TEST_0_DEVICE_ID);
			if(status!=XST_SUCCESS)
			{
				printf("Error, can't initialize accelerator.\n");
				return XST_FAILURE;
			}
			*/

			Xil_DCacheFlushRange((u32)A,50*sizeof(float));  // Cache
			Xil_DCacheFlushRange((u32)B,50*sizeof(float));

			XCde_emc_bench_Set_A(&hlsconv,(u32)A);  // ����
			XCde_emc_bench_Set_B(&hlsconv,(u32)B);
		//    print("-----\n\r");
		//	for(int i=0;i<50;i++){
		//		printf("%f ",B[i]);
		//	}
		//    print("\n\r");
			XTime_GetTime(&tCur);		//��ȡ��ʼʱ��
			XCde_emc_bench_Start(&hlsconv);              // start
			while(XCde_emc_bench_IsDone(&hlsconv)==0);   // done
			XTime_GetTime(&tEnd);
			tUsed=(float)((tEnd-tCur)*1000)/(COUNTS_PER_SECOND);
			tallused = tallused + tUsed;
			Xil_DCacheInvalidateRange((u32)B,50*sizeof(float));

	//		for(int i=0;i<5;i++){
			printf("%f ",B[3]);
	//		}

	//		print("\n\r");
	//		print("Hello World\n\r");
		 }
		 printf("\nHW ALL time is %lfms\n",tallused);
	//		print("\n=======\n\r");
	    cleanup_platform();
    return 0;
}
