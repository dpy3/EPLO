#include <cmath>
#include <cstring>
#include <cstdio>
#include <stdlib.h>
#include <ap_int.h>
#include <iostream>

using namespace std;
#define rand_max 2147483647
#define pi 3.1415926
#define Max_iter 200
#define sizepop 30
#define dim 10

float roa(volatile float *Par1,volatile float *Par2,volatile float *Par3,volatile float *Rpos_v2,volatile float *Rbest_flag);

int main()
{
	 float pos_v2[sizepop*dim*2];
	 float best_flag[dim+2];
	 float fit_iter[sizepop+2];
	 float Rpos_v2[sizepop*dim*2];
	 float Rbest_flag[dim+2];

	 float ub=5.12;
	 float lb=-5.12;

	 best_flag[dim]=10000;
	 best_flag[dim+1]=0;


	 //��ʼ����Ⱥ
	for(int i = 0; i < sizepop; i++)
	{
		for (int j=0;j<dim;j++)
		{
			pos_v2[i*dim+j]=(float)rand()/rand_max*(ub-lb)+lb; //lb��ub֮��������
			pos_v2[sizepop*dim+i*dim+j]=(float)rand()/rand_max*2*pi;
		}
	}

	for(int iter=1;iter<=Max_iter;iter++)
	{

		int num=(int)best_flag[dim+1];
		//������Ӧ��ֵ
		//Sphere function���Ժ���
		 for(int i = 0; i < (sizepop-num); i++)
		{

			float sum = 0.0;
			for (int j=0;j<dim;j++)
			{
				sum = sum +pos_v2[i*dim+j]*pos_v2[i*dim+j];
			}
			fit_iter[i] = sum;

/*
			 float x = pos_v2[i*dim];
			 float y = pos_v2[i*dim+1];
			 float xy=x*x+y*y;
			 fit_iter[i] = -( 1+cos (12*sqrt(xy)))/(xy/2+2);
*/
		}

		 fit_iter[sizepop]=iter;
		 fit_iter[sizepop+1]=1;

		 //�㷨���岿��
		 roa(&pos_v2[0],&best_flag[0],&fit_iter[0],&Rpos_v2[0],&Rbest_flag[0]);

		 memcpy((float*)pos_v2,(const float*)Rpos_v2,(sizepop*dim*2)*sizeof(float));
		 memcpy((float*)best_flag,(const float*)Rbest_flag,(dim+2)*sizeof(float));
	}


    cout << "����ֵ��:" << best_flag[dim]<<endl;
    return 0;
}
