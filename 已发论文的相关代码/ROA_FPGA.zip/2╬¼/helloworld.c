/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include <string.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xdebug.h"
#include "xroa.h"
#include <stdlib.h>
#include <math.h>
#include "xtime_l.h"
#include"xil_cache.h"

#define sizepop 30
#define dim 2
#define pi 3.1415926
#define Max_iter 200
#define ub 2
#define lb -2

int main()
{
    init_platform();
//    Xil_DCacheDisable();

	XRoa Xroa_inst;
	if(XRoa_Initialize(&Xroa_inst, XPAR_ROA_0_DEVICE_ID)!= XST_SUCCESS)
		printf("error initialize axi_dma\n");

	 float pos_v2[sizepop*dim*2];
	 float best_flag[dim+2];
	 float fit_iter[sizepop+2];
	 float *Rpos_v2 = (float*)malloc((sizepop*dim*2)*sizeof(float));
	 float *Rbest_flag = (float*)malloc((dim+2)*sizeof(float));

//ѭ����11��,cacheˢ��ʱ��һ�ε�ֵ��ƫ�ȡ2~11�ε�ֵ
for(int r=0;r<11;r++){

	XTime tStart,tEnd;
	u32 tUsed;
	XTime_GetTime(&tStart);

	 best_flag[dim]=10000;
	 best_flag[dim+1]=0;

	 //��ʼ����Ⱥ
	for(int i = 0; i < sizepop; i++)
	{
		for (int j=0;j<dim;j++)
		{
			pos_v2[i*dim+j]=(float)rand()/RAND_MAX*(ub-lb)+lb; //lb��ub֮��������
			pos_v2[sizepop*dim+i*dim+j]=(float)rand()/RAND_MAX*2*pi;
		}
	}

	//����Ѱ��
	for(int iter=1;iter<=Max_iter;iter++)
	{
		int num=(int)best_flag[dim+1];

	   //������Ⱥ����Ӧ��ֵ
/*
		 //sphere function(10)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float sum=0.0;
			 for(int j=0;j<dim;j++)
			 {
				 sum=sum+pos_v2[i*dim+j]*pos_v2[i*dim+j];
			 }
			 fit_iter[i] = sum;
		 }

		 //Rastrigin function(10)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float sum = 0.0;
			 for (int j=0;j<dim;j++)
			 {
				  sum = sum + (pos_v2[i*dim+j]*pos_v2[i*dim+j] -10*cos(2*pi*pos_v2[i*dim+j]));
			 }
			 fit_iter[i] = 10*dim + sum;
		 }

		 //sum squares function(10)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float sum = 0.0;
			 for (int j=1;j<=dim;j++)
			 {
				 float y = pos_v2[i*dim+j-1];
				 sum = sum + j*y*y;
			 }
			 fit_iter[i] = sum;
		 }

		 //Styblinski-tang function(10)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float sum = 0.0;
			 for (int j=0;j<dim;j++)
			 {
				 float y = pos_v2[i*dim+j];
				 sum = sum +pow(y,4) - 16*y*y + 5*y;
			 }
			 fit_iter[i] = sum/2;
		 }

		 //schwefel function(10)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float sum = 0.0;
			 for (int j=0;j<dim;j++)
			 {
				 float y = fabs(pos_v2[i*dim+j]);
				 sum = sum +pos_v2[i*dim+j]*sin(sqrt(y));
			  }
			 fit_iter[i] = 4189.829-sum;
		 }


		 //DropWave function(2)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float x1 = pos_v2[i*dim];
			 float x2 = pos_v2[i*dim+1];
			 float xy=x1*x1+x2*x2;
			 fit_iter[i] = -( 1+cos (12*sqrt(xy)))/(xy/2+2);
		 }

		 //Shubert function(2)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float sum1 = 0,sum2 = 0;
			 float new1 = 0,new2 = 0;
			 float x1 = pos_v2[i*dim];
			 float x2 = pos_v2[i*dim+1];
			 for (int j=1;j<=5;j++)
			 {
				 new1 = j * cos((j+1)*x1+j);
				 new2 = j * cos((j+1)*x2+j);
				 sum1 = sum1 + new1;
				 sum2 = sum2 + new2;
			 }
			 fit_iter[i] = sum1 * sum2;
		 }

		 //Three-hump camel function(2)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float x1 = pos_v2[i*dim];
			 float x2 = pos_v2[i*dim+1];
			 fit_iter[i] = 2*x1*x1 - 1.05*pow(x1,4) + pow(x1,6)/6.0 + x1*x2 + x2*x2;
		 }

		 //egg holder function(2)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float x1 = pos_v2[i*dim];
			 float x2 = pos_v2[i*dim+1];
			 float new1=fabs(x2+x1/2.0+47);
			 float new2=fabs(x1-(x2+47));
			 fit_iter[i] = -(x2+47)*sin(sqrt(new1))-x1*sin(sqrt(new2));
		 }

		 //levy n.13 function(2)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float x1 = pos_v2[i*dim];
			 float x2 = pos_v2[i*dim+1];
			 float p1=sin(3*3.14*x1);
			 float p2=sin(3*3.14*x2);
			 float p3=sin(2*3.14*x2);
			 fit_iter[i] = p1*p1+(x1-1)*(x1-1)*(1+p2*p2)+(x2-1)*(x2-1)*(1+p3*p3);
		 }
*/
		 //goldstein-price function(2)
		 for(int i=0;i<(sizepop-num);i++)
		 {
			 float x1 = pos_v2[i*dim];
			 float x2 = pos_v2[i*dim+1];
			 float new1=(1+(x1+x2+1)*(x1+x2+1)*(19-14*x1+3*x1*x1-14*x2+6*x1*x2+3*x2*x2));
			 float new2=(30+(2*x1-3*x2)*(2*x1-3*x2)*(18-32*x1+12*x1*x1+48*x2-36*x1*x2+27*x2*x2));
			 fit_iter[i] = new1*new2;
		 }


		fit_iter[sizepop]=iter;
		fit_iter[sizepop+1]=4;

	   Xil_DCacheFlushRange((u32)pos_v2, (sizepop*dim*2)*sizeof(float));
	   Xil_DCacheFlushRange((u32)best_flag, (dim+2)*sizeof(float));
	   Xil_DCacheFlushRange((u32)fit_iter, (sizepop+2)*sizeof(float));

	   //ִ�����岿��
	   XRoa_Set_Par1(&Xroa_inst,(u32)pos_v2);
	   XRoa_Set_Par2(&Xroa_inst,(u32)best_flag);
	   XRoa_Set_Par3(&Xroa_inst,(u32)fit_iter);
	   XRoa_Set_Rpos_v2(&Xroa_inst,(u32)Rpos_v2);
	   XRoa_Set_Rbest_flag(&Xroa_inst,(u32)Rbest_flag);
	   XRoa_Start(&Xroa_inst);
	   while(XRoa_IsDone(&Xroa_inst) == 0);

	   Xil_DCacheInvalidateRange((u32)Rpos_v2, (sizepop*dim*2)*sizeof(float));
	   Xil_DCacheInvalidateRange((u32)Rbest_flag, (dim+2)*sizeof(float));

	   memcpy((float*)pos_v2,(const float*)Rpos_v2,(sizepop*dim*2)*sizeof(float));
	   memcpy((float*)best_flag,(const float*)Rbest_flag,(dim+2)*sizeof(float));

	}

	XTime_GetTime(&tEnd);
	tUsed=((tEnd-tStart)*1000)/(COUNTS_PER_SECOND);
	printf("HW time is %ldms\n",tUsed);

	printf("run = %d, bestfit = %e\n",r,best_flag[dim]);

	Xil_DCacheFlush();

}
    cleanup_platform();
    return 0;
}
