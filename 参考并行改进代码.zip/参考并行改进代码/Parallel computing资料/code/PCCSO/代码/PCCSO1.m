function [Gbest,T] =PCCSO1( fhd,Dimension,Particle_Number,Mr,srd,smp,c,Max_Gen,VelMin,VelMax,popmin,popmax,varargin )
%CSO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��CSO
%-------------------------- Parameters Setting ----------------------------%
rand('state',sum(100*clock));
% w = 0.9;
nDIM =Dimension;
mr=Mr;
nDim=10;
% Seek.srd=srd;
% Seek.smp=smp;
maxgen = Max_Gen;
groups = 4;
nPOP = Particle_Number/groups;

% Seek.popmax = popmax;
% Seek.popmin = popmin;
% Trace.c=c;
% Trace.VelMin=VelMin;
% Trace.VelMax=VelMax;
% spc = rand();
r = rand();
for g = 1:groups
    for i = 1:nPOP
        % �������һ����Ⱥ
        group(g).pop(i,:) = popmin+(popmax-popmin)*rand(1,nDIM);    %��ʼ��Ⱥ
        group(g).V(i,:) = VelMin+(VelMax-VelMin)*rand(1,nDIM);  %��ʼ���ٶ�
        % ������Ӧ��
Max = -       ;
%------------------------------- The End ----------------------------------%
%-------------------------- Initialization --------------------------------%
%..
    end
    group(g).fitness = feval(fhd,group(g).pop',varargin{:});%��������������������������
end
for g = 1:groups
    [group(g).bestfitness,group(g).bestindex] = min(group(g).fitness);
%     group(g).GP = group(g).bestindex;
    group(g).gbest = group(g).pop(group(g).bestindex,:);   %ȫ�����
    group(g).fitnessgbest = group(g).bestfitness;%ȫ�������Ӧ��ֵ
    Gbest = group(1).fitnessgbest;
    GbestPosition = group(1).gbest;
end;
for g = 1:groups
    if group(g).fitnessgbest<Gbest
        Gbest = group(g).fitnessgbest;
        GbestPosition = group(g).gbest;
    end
end
Up = 10;
n=1000;
for g = 1:groups
    group(g).mu = zeros(1,nDim);
    group(g).sicma=10*ones(1,nDim);
end
n_Trace = nPOP*mr;

n_Trace = 6;
%------------------------------- The End ----------------------------------%
for G = 1:maxgen
    
    idx_Trace = randperm(nPOP,n_Trace);
    idx_Seek = setdiff(1:nPOP,idx_Trace);

    for g = 1:groups
        if rem(G,20) == 0%R1=20,20������һ�Σ�
            r = randperm(size(group,2),1);
            while(g==r)
                r = randperm(size(group,2),1);
            end
            group(g).pop(group(g).worseposition,:) = group(r).gbest;
           
        end
        %--------------------------- Seeking Mode ---------------------------%
        for i = 1:size(idx_Seek)
            group(g).pop(idx_Seek(i),:)= Up*generateIndividualR(group(g).mu ,group(g).sicma);
            spc = rand;
            %% �϶���ÿ��seeking cat ��spc����һ����������ô���ڿ�ͷ�����ȫ�ֱ���������
            
            if spc<0.5
                flag = 0;
            else
                flag = 1;
            end
            
            group(g).Copypop= repmat(group(g).pop(idx_Seek(i),:),smp,1);%..
            group(g).Copyfitness=repmat(group(g).fitness(idx_Seek(i)),smp,1);
            Sign = rand(smp,nDIM);
            Sign( Sign>=0.5 ) = 1;
            Sign( Sign<0.5 ) = -1;
            val = srd.*abs(group(g).pop(idx_Seek(i),:));
            if flag == 0
                for j = 1:smp
                    group(g).Copypop(j,:) = group(g).pop(idx_Seek(i),:)+ Sign(j,:).*val;  %��ʼ��Ⱥ
                    group(g).Copypop(j,:) = min(popmax,max(popmin,group(g).Copypop(j,:)));
                    %                     group(g).Copyfitness(j) = feval(fhd,group(g).Copypop(j,:)' ,varargin{:}); %��ʼ���ٶ�
                    %                     if group(g).Copyfitness(j) > Max
                    %                         Max = group(g).Copyfitness(j);
                    %                     end
                    %                     if group(g).Copyfitness(j)  < group(g).fitnessgbest
                    %                         group(g).gbest = group(g).Copypop(j,:);
                    %                         group(g).fitnessgbest =group(g).Copyfitness(j);
                    %                     end
                end
                %% copy��catӦ��Ѱ��һ������ֵ�����ҵ�����ֵ��λ��
            else
                %                  group(g).gbest = group.pop;
                %                 group(g).fitnessgbest= feval(fhd, group(g).gbest,varargin{:});
                %% Ӧ�ý���idx_Seek��i)ֻè��ֵ���һ��copy
                group(g).Copy(1,:) = group(g).pop(idx_Seek(i),:);
                for j = 2:smp
                    group(g).Copypop(j,:)=  group(g).pop(idx_Seek(i),:)+Sign(j,:).*val;
                    for d = 1:nDIM
                        group(g).Copypop(j,:) = min(popmax,max(popmin,group(g).Copypop(j,:)));
                    end
                    %                     group(g).Copyfitness(j) =feval(fhd,group(g).Copypop(j,:)',varargin{:});
                    %
                    %                     if   group(g).Copyfitness(j)> Max
                    %                         Max =  group(g).Copyfitness(j);
                    %                     end
                    %                 end
                    %% ͬ����Ѱ��һ�����ŵ�ֵ������
                    %                 if group(g).Copyfitness(idx_Seek(i))  < group(g).fitnessgbest
                    %                     group(g).gbest = group(g).Copypop(i,:);
                    %                     group(g).fitnessgbest =group(g).Copyfitness(i);
                    %                 end
                end
                
            end
            group(g).Copyfitness = feval(fhd,group(g).Copypop',varargin{:});
            [mincopyfitness,mincopyidex] = min(group(g).Copyfitness);
            [maxcopyfitness,maxcopyidex] = max(group(g).Copyfitness);
           Selection = rand;
            for j = 1:smp
                p(j) = abs((group(g).Copyfitness(j)-maxcopyfitness))/(maxcopyfitness-mincopyfitness);
                if Selection < p(j)
                    group(g).fitness(idx_Seek(i)) = group(g).Copyfitness(j);
                    group(g).pop(idx_Seek(i),:) = group(g).Copypop(j,:);
                    break;
                end
            end
             [group(g).max,group(g).worseposition] = max(group(g).fitness);
            if group(g).fitness(idx_Seek(i)) < group(g).fitnessgbest
                                group(g).fitnessgbest = group(g).fitness(idx_Seek(i));
                group(g).gbest = group(g).pop(idx_Seek(i),:);
                
               group(g).mu = updateMuPV( group(g).gbest ,group(g).pop(idx_Seek(i),:),group(g).mu,n,nDIM);
               group(g).sicma = updateSicmaPV( group(g).gbest ,group(g).pop(idx_Seek(i),:),group(g).mu,group(g).sicma,n,nDIM);  
              group(g).pop(idx_Seek(i),:)= Up*generateIndividualR(group(g).mu,group(g).sicma);

            end
        end
            %% seek���������������ٸ�����Ⱥ��fitness����ֵ��˳���ҵ�fitness Maxֵ
            
            
            %--------------------------------------------------------------------%
            %--------------------------- Tracing Mode ---------------------------%
            
            for m = 1:size(idx_Trace,2)
                %-------------------------- updata velocity ------------------------%
                group(g).V(idx_Trace(m),:) = group(g).V(idx_Trace(m),:)+rand()*c*(group(g).gbest-group(g).pop(idx_Trace(m),:));
                for d = 1:nDIM
                     group(g).V(idx_Trace(m),d) = min(VelMax,max(VelMin,group(g).V(idx_Trace(m),d)));
                end
                %-------------------------------------------------------------------%
                
                %-------------------------- updata location ------------------------%
                group(g).pop(idx_Trace(m),:) = group(g).pop(idx_Trace(m),:)+group(g).V(idx_Trace(m),:);%����λ�ù�ʽ
                 for d = 1:nDIM
                     group(g).pop(idx_Trace(m),d) = min(popmax,max(popmin,group(g).pop(idx_Trace(m),d)));
                end
                %-------------------------------------------------------------------%
            end
            
           
            group(g).fitness = feval(fhd,group(g).pop',varargin{:});
            [group(g).max,group(g).worseposition] = max(group(g).fitness);
            for i = 1:nPOP
                if group(g).fitness(i)<group(g).fitnessgbest
                    group(g).fitnessgbest = group(g).fitness(i);
                    group(g).gbest = group(g).pop(i,:);
                    %
                end
                if group(g).fitnessgbest < Gbest
                    Gbest = group(g).fitnessgbest;
                    GbestPosition = group(g).gbest;
                end
            end
        end
        
    %     T(G) = groupgBest.Cost;
    idx_Trace = randperm(nPOP,n_Trace);
    idx_Seek = setdiff(1:nPOP,idx_Trace);
    
    %------------------------------- The End ----------------------------------%
    T(G) = Gbest;
end

%figure(varargin{:});
% plot(T(1:50:1000),'r-o','LineWidth',1,'Marker','o','MarkerFaceColor','red');
% hold on;
% legend('CSO');

end






