# Optimization-of-remote-sensing-image-segmentation-by-a-customized-parallel-sine-cosine-algorithm-ba
The source code of the paper 'Optimization of remote sensing image segmentation by a customized parallel sine cosine algorithm based on Taguchi method'
# 1. How to use
## 1.1 Example folder
   This is our example, you can directly use TPSCA-PCNN.m to get the result of TSCA-PCNN.
## 1.2 Home folder
   There are TPSCA, Taguchi and fun source code
