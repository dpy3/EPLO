function fit= func14_schwefel_222(x)
fit=sum(abs(x))+prod(abs(x));
end

