function yout = y(x)
yout=1+(x+1)/4;
end

